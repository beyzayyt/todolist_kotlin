package com.example.todolist

import android.os.Bundle
import android.view.View
import android.widget.CheckBox
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*
import android.support.design.widget.FloatingActionButton


class MainActivity : AppCompatActivity(), View.OnClickListener{

    override fun onCreate(savedInstanceState: Bundle?) { // programı ilk calıstırdıgımızda otomatik calısır.
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main) // hangi sayfa calısacak
        //dinamic date
        val textView: TextView = findViewById(R.id.dateAndTime)
        val simpleDateFormat = SimpleDateFormat("dd.MM.yyyy ")
        val currentDateAndTime: String = simpleDateFormat.format(Date())
        textView.text = currentDateAndTime


        //check box
        val checkBox1 = findViewById<CheckBox>(R.id.checkBox1)
        val checkBox2 = findViewById<CheckBox>(R.id.checkBox2)
        val checkBox3 = findViewById<CheckBox>(R.id.checkBox3)
        val checkBox4 = findViewById<CheckBox>(R.id.checkBox4)

        checkBox1.setOnClickListener(this)
        checkBox2.setOnClickListener(this)
        checkBox3.setOnClickListener(this)
        checkBox4.setOnClickListener(this)



    }

    override fun onClick(v: View?) {
        v as CheckBox
        var isChecked :Boolean = v.isChecked
        when(v.id){
            R.id.checkBox1 -> if(isChecked){
                print("tick1 is markable")
            }
            R.id.checkBox2 -> if(isChecked)
            {
                print("tick2 is markable")
            }
            R.id.checkBox3 -> if(isChecked)
            {
                print("tick3 is markable")
            }
            R.id.checkBox4 -> if(isChecked)
            {
                print("tick3 is markable")
            }
        }


        }







    }




